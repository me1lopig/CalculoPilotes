import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from engine import solve_consolidation

# Configuración de la página
st.set_page_config(page_title="Consolidación de Suelos - Terzaghi", layout="wide")

st.title("Consolidación de Suelos: Método de Diferencias Finitas")
st.markdown("""
Esta aplicación resuelve la **Ecuación de la Consolidación de Terzaghi** para diferentes condiciones de drenaje.
Migración de la herramienta original de MATLAB a Streamlit.
""")

# Barra lateral para entradas de usuario
st.sidebar.header("Parámetros de Entrada")

# Entradas de usuario
longitud = st.sidebar.number_input("Espesor del estrato [m]", value=10.0, min_value=0.1, step=0.5)
Ti = st.sidebar.number_input("Carga exterior [kPa]", value=100.0, min_value=1.0, step=10.0)
cv = st.sidebar.number_input("Coeficiente de consolidación [m²/día]", value=0.01, min_value=0.0001, format="%.4f")
mv = st.sidebar.number_input("Coeficiente de compresibilidad volumétrico [m²/kN]", value=0.0005, min_value=0.00001, format="%.5f")

st.sidebar.divider()
st.sidebar.subheader("Parámetros de la Malla")
h = st.sidebar.number_input("Incremento de x [m]", value=1.0, min_value=0.1, step=0.1)
k = st.sidebar.number_input("Incremento de t [días]", value=1.0, min_value=0.1, step=0.1)
max_U_pct = st.sidebar.slider("Máximo grado de consolidación [%]", 1, 99, 90)

st.sidebar.divider()
tipo_calculo_label = st.sidebar.selectbox(
    "Condiciones de Contorno",
    ["Doble Drenaje (Permeable-Permeable)", 
     "Drenaje Superior (Permeable-Impermeable)", 
     "Drenaje Inferior (Impermeable-Permeable)"]
)

# Mapeo de etiquetas a valores numéricos
tipo_calculo_map = {
    "Doble Drenaje (Permeable-Permeable)": 1,
    "Drenaje Superior (Permeable-Impermeable)": 2,
    "Drenaje Inferior (Impermeable-Permeable)": 3
}
tipo_calculo = tipo_calculo_map[tipo_calculo_label]

# Botón para ejecutar el cálculo
if st.sidebar.button("Ejecutar Simulación", type="primary"):
    # Llamada al motor de cálculo
    results = solve_consolidation(longitud, Ti, cv, mv, h, k, max_U_pct, tipo_calculo)
    
    if "error" in results:
        st.error(results["error"])
    else:
        # Mostrar resultados en pestañas
        tab1, tab2, tab3 = st.tabs(["📊 Gráficas de Evolución", "📉 Perfiles de Presión", "📋 Datos Tabulados"])
        
        with tab1:
            col1, col2 = st.columns(2)
            
            # Gráfica 1: Asientos vs Tiempo
            fig_asiento = go.Figure()
            fig_asiento.add_trace(go.Scatter(x=results["tiempo"], y=results["asiento"], mode='lines', name='Asiento'))
            fig_asiento.update_layout(title="Variación de los Asientos en función del Tiempo",
                                     xaxis_title="Tiempo [días]", yaxis_title="Asientos [cm]",
                                     yaxis_autorange="reversed")
            col1.plotly_chart(fig_asiento, use_container_width=True)
            
            # Gráfica 2: Grado de Consolidación vs Tiempo
            fig_U = go.Figure()
            fig_U.add_trace(go.Scatter(x=results["tiempo"], y=[u*100 for u in results["grado_consolidacion"]], mode='lines', name='U%'))
            fig_U.update_layout(title="Variación Grado de Consolidación / Tiempo",
                               xaxis_title="Tiempo [días]", yaxis_title="Grado de Consolidación [%]",
                               yaxis_autorange="reversed")
            col2.plotly_chart(fig_U, use_container_width=True)
            
            col3, col4 = st.columns(2)
            
            # Gráfica 3: Caudal vs Tiempo
            fig_Q = go.Figure()
            fig_Q.add_trace(go.Scatter(x=results["tiempo"], y=results["caudal"], mode='lines', name='Caudal'))
            fig_Q.update_layout(title="Variación del Caudal en función del Tiempo",
                               xaxis_title="Tiempo [días]", yaxis_title="Caudal [m³/día/m²]")
            col3.plotly_chart(fig_Q, use_container_width=True)
            
            # Gráfica 4: U% vs Factor Tiempo (Semilog)
            fig_Tv = go.Figure()
            fig_Tv.add_trace(go.Scatter(x=results["factor_tiempo"], y=[u*100 for u in results["grado_consolidacion"]], mode='lines', name='U%'))
            fig_Tv.update_layout(title="Grado de Consolidación / Factor Tiempo",
                                xaxis_title="Factor Tiempo (Tv)", yaxis_title="Grado de Consolidación [%]",
                                xaxis_type="log", yaxis_autorange="reversed")
            col4.plotly_chart(fig_Tv, use_container_width=True)
            
        with tab2:
            # Gráfica de Perfiles de Presión
            fig_perfil = go.Figure()
            x_coords = np.linspace(0, longitud, int(np.floor(longitud/h)) + 1)
            
            # Mostrar solo algunos perfiles para no saturar la gráfica
            num_perfiles = len(results["perfiles_presion"])
            indices_to_show = np.linspace(0, num_perfiles-1, min(10, num_perfiles), dtype=int)
            
            for idx in indices_to_show:
                t, u_perfil = results["perfiles_presion"][idx]
                fig_perfil.add_trace(go.Scatter(x=u_perfil, y=x_coords, mode='lines', name=f"t={t:.1f} d"))
            
            fig_perfil.update_layout(title="Perfil de Presión de Poro / Profundidad",
                                    xaxis_title="Presión de Poro [kPa]", yaxis_title="Profundidad [m]",
                                    yaxis_autorange="reversed", height=600)
            st.plotly_chart(fig_perfil, use_container_width=True)
            
        with tab3:
            # Mostrar tabla de datos
            df_results = pd.DataFrame({
                "Tiempo [días]": results["tiempo"],
                "Grado Consolidación [%]": [u*100 for u in results["grado_consolidacion"]],
                "Asiento [cm]": results["asiento"],
                "Caudal [m³/día/m²]": results["caudal"],
                "Factor Tiempo (Tv)": results["factor_tiempo"]
            })
            st.dataframe(df_results.style.format("{:.4f}"), use_container_width=True)
            
            # Botón de descarga
            csv = df_results.to_csv(index=False).encode('utf-8')
            st.download_button("Descargar Resultados (CSV)", csv, "resultados_consolidacion.csv", "text/csv")

else:
    st.info("Ajuste los parámetros en la barra lateral y haga clic en 'Ejecutar Simulación' para ver los resultados.")
    
    # Mostrar una imagen o esquema de las condiciones de contorno (opcional)
    st.subheader("Esquema del Problema")
    st.markdown("""
    - **Doble Drenaje**: El agua puede salir por arriba y por abajo.
    - **Drenaje Superior**: El agua solo sale por arriba (base impermeable).
    - **Drenaje Inferior**: El agua solo sale por abajo (superficie impermeable).
    """)
