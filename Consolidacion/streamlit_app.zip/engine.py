import numpy as np

def solve_consolidation(longitud, Ti, cv, mv, h, k, max_U_pct, tipo_calculo):
    """
    Resuelve la ecuación de consolidación de Terzaghi mediante diferencias finitas.
    
    Parámetros:
    - longitud: Espesor del estrato [m]
    - Ti: Carga exterior [kPa]
    - cv: Coeficiente de consolidación [m2/dia]
    - mv: Coeficiente de compresibilidad volumétrico [m2/kN]
    - h: Incremento de x [m]
    - k: Incremento de t [dias]
    - max_U_pct: Máximo grado de consolidación [%]
    - tipo_calculo: 1 (Doble), 2 (Superior), 3 (Inferior)
    
    Retorna:
    - Un diccionario con los resultados históricos para graficar.
    """
    
    # Parámetros derivados
    s_max = longitud * mv * Ti
    permeabilidad = cv * mv * 10  # m/dia (asumiendo factor 10 de MATLAB)
    alfa = cv * k / (h**2)
    
    if alfa > 0.5:
        return {"error": f"El modelo no es convergente (alfa = {alfa:.3f} > 0.5). Reduzca el incremento de tiempo (k) o aumente el de espacio (h)."}
    
    nx = int(np.floor(longitud / h))
    x = np.linspace(0, longitud, nx + 1)
    
    # Inicialización de presiones de poro (u0)
    u0 = np.ones(nx + 1) * Ti
    
    # Ajuste inicial de condiciones de contorno (suavizado como en MATLAB)
    if tipo_calculo == 1: # Doble drenaje (Permeable-Permeable)
        u0[0] = Ti / 2
        u0[nx] = Ti / 2
    elif tipo_calculo == 2: # Drenaje Superior (Permeable-Impermeable)
        u0[0] = 0
    elif tipo_calculo == 3: # Drenaje Inferior (Impermeable-Permeable)
        u0[nx] = 0
        
    # Listas para almacenar resultados
    history = {
        "tiempo": [0],
        "grado_consolidacion": [0],
        "asiento": [0],
        "caudal": [0],
        "factor_tiempo": [0],
        "perfiles_presion": [(0, u0.copy())] # (tiempo, perfil)
    }
    
    t_actual = 0
    grado_consolidacion = 0
    u = u0.copy()
    
    # Bucle temporal
    while grado_consolidacion < (max_U_pct / 100.0):
        t_actual += k
        
        # Cálculo de presiones en nodos internos
        for i in range(1, nx):
            u[i] = alfa * (u0[i+1] + u0[i-1]) + (1 - 2*alfa) * u0[i]
            
        # Condiciones de contorno para el siguiente paso
        if tipo_calculo == 1: # Doble
            u[0] = 0
            u[nx] = 0
            derivada = u[1] / h # Para caudal (en el contorno superior)
        elif tipo_calculo == 2: # Superior
            u[0] = 0
            # Nodo impermeable inferior (derivada nula: u[nx+1] = u[nx-1])
            u[nx] = alfa * (2 * u0[nx-1]) + (1 - 2*alfa) * u0[nx]
            derivada = u[1] / h
        elif tipo_calculo == 3: # Inferior
            u[nx] = 0
            # Nodo impermeable superior (derivada nula: u[-1] = u[1])
            u[0] = alfa * (2 * u0[1]) + (1 - 2*alfa) * u0[0]
            derivada = abs(u[nx] - u[nx-1]) / h
            
        # Cálculo del Grado de Consolidación (U) mediante regla del trapecio
        # Area bajo la curva de presiones actual
        area_actual = np.trapz(u, x)
        area_total = longitud * Ti
        grado_consolidacion = (area_total - area_actual) / area_total
        
        # Asiento
        asiento = s_max * grado_consolidacion * 100 # Convertir a cm
        
        # Caudal
        Q = permeabilidad * derivada
        
        # Factor Tiempo Tv
        Tv = (t_actual * cv) / (longitud**2)
        
        # Guardar resultados
        history["tiempo"].append(t_actual)
        history["grado_consolidacion"].append(grado_consolidacion)
        history["asiento"].append(asiento)
        history["caudal"].append(Q)
        history["factor_tiempo"].append(Tv)
        
        # Guardar perfil de presión cada cierto tiempo para no saturar
        if len(history["tiempo"]) % max(1, int(10/k)) == 0 or grado_consolidacion >= (max_U_pct / 100.0):
            history["perfiles_presion"].append((t_actual, u.copy()))
            
        u0 = u.copy()
        
        # Seguridad para evitar bucles infinitos
        if len(history["tiempo"]) > 10000:
            break
            
    return history
